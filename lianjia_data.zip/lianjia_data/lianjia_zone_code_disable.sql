/*
Navicat PGSQL Data Transfer

Source Server         : localhost
Source Server Version : 90411
Source Host           : localhost:5432
Source Database       : superpower
Source Schema         : public

Target Server Type    : PGSQL
Target Server Version : 90411
File Encoding         : 65001

Date: 2018-03-23 12:51:28
*/


-- ----------------------------
-- Table structure for lianjia_zone_code_disable
-- ----------------------------
DROP TABLE IF EXISTS "public"."lianjia_zone_code_disable";
CREATE TABLE "public"."lianjia_zone_code_disable" (
"gaode_regionid" varchar(50) COLLATE "default" NOT NULL,
"region_name" varchar(50) COLLATE "default"
)
WITH (OIDS=FALSE)

;

-- ----------------------------
-- Records of lianjia_zone_code_disable
-- ----------------------------
INSERT INTO "public"."lianjia_zone_code_disable" VALUES ('B023B0203C', '曲院社区');
INSERT INTO "public"."lianjia_zone_code_disable" VALUES ('B023B05RZ6', '保亭社区东2区');
INSERT INTO "public"."lianjia_zone_code_disable" VALUES ('B023B05TRC', '城厢街道陈公桥社区');
INSERT INTO "public"."lianjia_zone_code_disable" VALUES ('B023B05YK3', '甘长苑');
INSERT INTO "public"."lianjia_zone_code_disable" VALUES ('B023B06BLS', '立志园');
INSERT INTO "public"."lianjia_zone_code_disable" VALUES ('B023B06P84', '霞江民工公寓楼');
INSERT INTO "public"."lianjia_zone_code_disable" VALUES ('B023B072HF', '中舟社区再行小区');
INSERT INTO "public"."lianjia_zone_code_disable" VALUES ('B023B07CL0', '东坡路社区');
INSERT INTO "public"."lianjia_zone_code_disable" VALUES ('B023B08SDF', '三新家园西区');
INSERT INTO "public"."lianjia_zone_code_disable" VALUES ('B023B08SDI', '三新家园东区');
INSERT INTO "public"."lianjia_zone_code_disable" VALUES ('B023B08SE7', '杭锅新村西区');
INSERT INTO "public"."lianjia_zone_code_disable" VALUES ('B023B08T6U', '华江塑料有限公司宿舍');
INSERT INTO "public"."lianjia_zone_code_disable" VALUES ('B023B08YJQ', '平远里');
INSERT INTO "public"."lianjia_zone_code_disable" VALUES ('B023B08YLN', '小营巷社区');
INSERT INTO "public"."lianjia_zone_code_disable" VALUES ('B023B090SL', '葵巷社区北区');
INSERT INTO "public"."lianjia_zone_code_disable" VALUES ('B023B0934C', '珠儿潭社区');
INSERT INTO "public"."lianjia_zone_code_disable" VALUES ('B023B09G15', '环北新村社区');
INSERT INTO "public"."lianjia_zone_code_disable" VALUES ('B023B09JLK', '体东社区东区');
INSERT INTO "public"."lianjia_zone_code_disable" VALUES ('B023B09JMY', '瓜山南苑新居');
INSERT INTO "public"."lianjia_zone_code_disable" VALUES ('B023B09JND', '大通新村小区');
INSERT INTO "public"."lianjia_zone_code_disable" VALUES ('B023B09XA4', '景东小区');
INSERT INTO "public"."lianjia_zone_code_disable" VALUES ('B023B09Z3R', '长瀛苑');
INSERT INTO "public"."lianjia_zone_code_disable" VALUES ('B023B0A4WI', '七格小区');
INSERT INTO "public"."lianjia_zone_code_disable" VALUES ('B023B0A5I3', '崇化住宅区西区');
INSERT INTO "public"."lianjia_zone_code_disable" VALUES ('B023B0A7E2', '格林园');
INSERT INTO "public"."lianjia_zone_code_disable" VALUES ('B023B0A925', '崇光路社区');
INSERT INTO "public"."lianjia_zone_code_disable" VALUES ('B023B0A926', '杭玻阔板桥社区');
INSERT INTO "public"."lianjia_zone_code_disable" VALUES ('B023B0A92C', '辰秀嘉园北区');
INSERT INTO "public"."lianjia_zone_code_disable" VALUES ('B023B0A9Z0', '留云苑');
INSERT INTO "public"."lianjia_zone_code_disable" VALUES ('B023B0AAJ1', '横塘3区');
INSERT INTO "public"."lianjia_zone_code_disable" VALUES ('B023B0AAJ4', '横塘1区');
INSERT INTO "public"."lianjia_zone_code_disable" VALUES ('B023B0AAJ7', '东山弄小区');
INSERT INTO "public"."lianjia_zone_code_disable" VALUES ('B023B0ADSO', '兴隆社区');
INSERT INTO "public"."lianjia_zone_code_disable" VALUES ('B023B0BH4C', '蔡马新村');
INSERT INTO "public"."lianjia_zone_code_disable" VALUES ('B023B0BS50', '丹阳');
INSERT INTO "public"."lianjia_zone_code_disable" VALUES ('B023B0BY1U', '中舟社区岳帅小区');
INSERT INTO "public"."lianjia_zone_code_disable" VALUES ('B023B13KM7', '五福北区');
INSERT INTO "public"."lianjia_zone_code_disable" VALUES ('B023B13M9P', '棉麻场社区');
INSERT INTO "public"."lianjia_zone_code_disable" VALUES ('B023B13NYY', '火炬小区东区');
INSERT INTO "public"."lianjia_zone_code_disable" VALUES ('B023B142QL', '向塘小区');
INSERT INTO "public"."lianjia_zone_code_disable" VALUES ('B023B14ED9', '体东社区西区');
INSERT INTO "public"."lianjia_zone_code_disable" VALUES ('B023B14PEQ', '轧钢小区');
INSERT INTO "public"."lianjia_zone_code_disable" VALUES ('B023B16BO6', '延安新村北区');
INSERT INTO "public"."lianjia_zone_code_disable" VALUES ('B023B17AJG', '锡铂园');
INSERT INTO "public"."lianjia_zone_code_disable" VALUES ('B023B18D0D', '葵巷社区南区');
INSERT INTO "public"."lianjia_zone_code_disable" VALUES ('B023B18D5D', '兴隆社区西区');
INSERT INTO "public"."lianjia_zone_code_disable" VALUES ('B023B18D6J', '小洋苑');
INSERT INTO "public"."lianjia_zone_code_disable" VALUES ('B023B1ABH5', '松龄苑');
INSERT INTO "public"."lianjia_zone_code_disable" VALUES ('B023B1D0FQ', '坚匏别墅');
INSERT INTO "public"."lianjia_zone_code_disable" VALUES ('B023B1DUZK', '五福新村东区');
INSERT INTO "public"."lianjia_zone_code_disable" VALUES ('B023B1ELYO', '断河头小区');
INSERT INTO "public"."lianjia_zone_code_disable" VALUES ('B023B1GSMD', '中南木业员工宿舍');
INSERT INTO "public"."lianjia_zone_code_disable" VALUES ('B023B1H7IH', '木村公寓楼');
INSERT INTO "public"."lianjia_zone_code_disable" VALUES ('B023F02L95', '永利新村');
INSERT INTO "public"."lianjia_zone_code_disable" VALUES ('B0FFF0DP1Q', '中舟社区珠埠小区');
INSERT INTO "public"."lianjia_zone_code_disable" VALUES ('B0FFF0E5C5', '严村里北区');
INSERT INTO "public"."lianjia_zone_code_disable" VALUES ('B0FFF0EW25', '万科草庄西岸');
INSERT INTO "public"."lianjia_zone_code_disable" VALUES ('B0FFF2HUF9', '严村里南区');
INSERT INTO "public"."lianjia_zone_code_disable" VALUES ('B0FFF39LVK', '五堡1区');
INSERT INTO "public"."lianjia_zone_code_disable" VALUES ('B0FFF3F1PE', '立业园');
INSERT INTO "public"."lianjia_zone_code_disable" VALUES ('B0FFF6WNWA', '石塘苑');
INSERT INTO "public"."lianjia_zone_code_disable" VALUES ('B0FFF74YQL', '油树下社区阮家埭新村');
INSERT INTO "public"."lianjia_zone_code_disable" VALUES ('B0FFF80IAE', '张妙苑');
INSERT INTO "public"."lianjia_zone_code_disable" VALUES ('B0FFF81LFA', '新塘苑');
INSERT INTO "public"."lianjia_zone_code_disable" VALUES ('B0FFFFZIL5', '璞俪洋房');
INSERT INTO "public"."lianjia_zone_code_disable" VALUES ('B0FFFGXBPK', '蔬科后');
INSERT INTO "public"."lianjia_zone_code_disable" VALUES ('B0FFFGXG8I', '元沙西区');
INSERT INTO "public"."lianjia_zone_code_disable" VALUES ('B0FFFHB52N', '霞晖北村');
INSERT INTO "public"."lianjia_zone_code_disable" VALUES ('B0FFFQGNAN', '联庄1区');
INSERT INTO "public"."lianjia_zone_code_disable" VALUES ('B0FFFQV73T', '元沙东区');
INSERT INTO "public"."lianjia_zone_code_disable" VALUES ('B0FFFSPQPF', '联庄4区');
INSERT INTO "public"."lianjia_zone_code_disable" VALUES ('B0FFFT9YTQ', '金二社区');
INSERT INTO "public"."lianjia_zone_code_disable" VALUES ('B0FFFVFXGN', '皋塘东1区');
INSERT INTO "public"."lianjia_zone_code_disable" VALUES ('B0FFFYTIB9', '供销社小区');
INSERT INTO "public"."lianjia_zone_code_disable" VALUES ('B0FFFZY5V0', '总管堂社区');
INSERT INTO "public"."lianjia_zone_code_disable" VALUES ('B0FFG515YM', '蒋村西溪人家');
INSERT INTO "public"."lianjia_zone_code_disable" VALUES ('B0FFG974W1', '速冻厂小区');
INSERT INTO "public"."lianjia_zone_code_disable" VALUES ('B0FFG97HGU', '普德人家');
INSERT INTO "public"."lianjia_zone_code_disable" VALUES ('B0FFGAT0I1', '葵巷社区中区');
INSERT INTO "public"."lianjia_zone_code_disable" VALUES ('B0FFGATK95', '孙村苑');
INSERT INTO "public"."lianjia_zone_code_disable" VALUES ('B0FFGBDUT3', '三卫社区');
INSERT INTO "public"."lianjia_zone_code_disable" VALUES ('B0FFGCFQ4P', '东宝路18号小区');
INSERT INTO "public"."lianjia_zone_code_disable" VALUES ('B0FFGFP6SK', '萍水人家');
INSERT INTO "public"."lianjia_zone_code_disable" VALUES ('B0FFGI8OMQ', '水韵康桥康泽苑');
INSERT INTO "public"."lianjia_zone_code_disable" VALUES ('B0FFGLWUX5', '荣庄社区一体化拆迁安置房');
INSERT INTO "public"."lianjia_zone_code_disable" VALUES ('B0FFGMDN86', '水兰苑');
INSERT INTO "public"."lianjia_zone_code_disable" VALUES ('B0FFH0IMH0', '祥宁人家');
INSERT INTO "public"."lianjia_zone_code_disable" VALUES ('B0FFH0OYIB', '火炬小区西区');
INSERT INTO "public"."lianjia_zone_code_disable" VALUES ('B0FFH15DIY', '同心6区');
INSERT INTO "public"."lianjia_zone_code_disable" VALUES ('B0FFH7S5RU', '景运人家');
INSERT INTO "public"."lianjia_zone_code_disable" VALUES ('B0FFHCSO4Q', '梦溪村');
INSERT INTO "public"."lianjia_zone_code_disable" VALUES ('B0FFHK0AMV', '华海园3期');
INSERT INTO "public"."lianjia_zone_code_disable" VALUES ('B0FFHX7R2Y', '花圃铁路新村北区');
INSERT INTO "public"."lianjia_zone_code_disable" VALUES ('B0FFHYIHRY', '五福新村西区');

-- ----------------------------
-- Alter Sequences Owned By 
-- ----------------------------

-- ----------------------------
-- Primary Key structure for table lianjia_zone_code_disable
-- ----------------------------
ALTER TABLE "public"."lianjia_zone_code_disable" ADD PRIMARY KEY ("gaode_regionid");
